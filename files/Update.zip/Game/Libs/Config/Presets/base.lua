
function FakeOverrideParams(gameParams, stats)
	gameParams.Stamina = {
    maxStamina = 100 * stats.staminaMul,
    lowStaminaLevel = 25,
    regenProne = 25,
    regenCrouch = 25,
    regenStand = 25,
    regenWalk = 25,
    regenJump = 0,
    regenKnockback = 2,
    knockbackStandThreshold = 25,
    jumpCost = 10
  }
  gameParams.minStaminaToStartHaste = 0.25
  gameParams.Stamina.pushMin = 0
  gameParams.strafeMultiplier = 0.7
  gameParams.backwardMultiplier = 0.5
  gameParams.proneMultiplier = 0.5
  gameParams.jumpHeight = 0.7
  for _,i in pairs(gameParams.stance) do
    if i.stanceId == 0 then
      i.normalSpeed = 1
      i.maxSpeed = 5.5
    end
  end
  gameParams.Damage = {
    health = 125 * stats.healthMul,
    absorption = stats.absorption,
    resistance = stats.resistance,
    armorHealth = stats.armorHealth,
    melee_res = stats.melee_res,
    splash_res = stats.splash_res,
    res_head = stats.res_head,
    res_legs = stats.res_legs,
    res_arms = stats.res_arms,
    res_body = stats.res_body,
    res_kn = stats.res_kn,
    res_pt = stats.res_pt,
    res_ar = stats.res_ar,
    res_sr = stats.res_sr,
    res_mg = stats.res_mg,
    res_hmg = stats.res_hmg,
    res_smg = stats.res_smg,
    res_shg = stats.res_shg,
    ignore_bullet_body = stats.ignore_bullet_body,
    ignore_bullet_head = stats.ignore_bullet_head,
    poison_grenade_damage_mul = stats.poison_grenade_damage_mul > 0 and stats.poison_grenade_damage_mul or 1,
    camera_shake_mul = stats.camera_shake_mul
  }
  local preset = ""
  preset = MainSettings.MyPresStr
  gameParams.inventory = dofile("Game\\Libs\\Config\\Presets\\"..preset)
  gameParams.teamModels = {
    black = {
      player = "objects/characters/presets/default_editor.cpf",
      arms = "Objects/Characters/soldier/arms/soldier_arms_03/soldier_arms_03_ed_fp.chr"
    },
    tan = {
      player = "objects/characters/presets/default_editor.cpf",
      arms = "Objects/Characters/soldier/arms/soldier_arms_03/soldier_arms_03_ed_fp.chr"
    }
  }
  gameParams.mouseSensitivity = {
    {
      stance = 0,
      scale = 1,
      angle = 180
    },
    {
      stance = 1,
      scale = 1,
      angle = 80
    },
    {
      stance = 2,
      scale = 1,
      angle = 90
    },
    {
      stance = 5,
      scale = 1,
      angle = 180
    }
  }
  if not gameParams.inventory and gameParams.inventory.items then return end
  for _,q in pairs(gameParams.inventory.items) do
	if not AllWeaponsTable then lfile("Game//Libs//Config//Presets//AllWeaponsTable.lua") end;
	local weapon = AllWeaponsTable[q.name]
	if weapon and weapon.sockets then
		if weapon.sockets.muzzle and weapon.sockets.muzzle[1] then
			for _,i in pairs(weapon.sockets.muzzle) do
				table.insert(gameParams.inventory.attachments, {name = i, attachTo = q.name}) 
			end
		end			
		if weapon.sockets.scope and weapon.sockets.scope[1] then
			for _,i in pairs(weapon.sockets.scope) do
				table.insert(gameParams.inventory.attachments, {name = i, attachTo = q.name}) 
			end
		end			
		if weapon.sockets.underbarrel and weapon.sockets.underbarrel[1] then
			for _,i in pairs(weapon.sockets.underbarrel) do
				table.insert(gameParams.inventory.attachments, {name = i, attachTo = q.name}) 
			end
		end
	end
end
end
return FakeOverrideParams